package com.example.coursemanagement.repository;

import com.example.coursemanagement.model.*;
import org.springframework.stereotype.Repository;

import java.util.*;

@Repository
public class InstructorRepository {
    public List<Instructor> findAll() {
        return Arrays.asList(new Instructor(1L, "A", "a@gmail.com"), new Instructor(2L, "B", "b@gmail.com"));
    }
}
