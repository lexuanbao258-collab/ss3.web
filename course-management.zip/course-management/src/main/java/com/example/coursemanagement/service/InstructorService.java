package com.example.coursemanagement.service;

import com.example.coursemanagement.repository.*;
import org.springframework.stereotype.Service;

import java.util.*;

import com.example.coursemanagement.model.*;

@Service
public class InstructorService {
    private final InstructorRepository repo;

    public InstructorService(InstructorRepository repo) {
        this.repo = repo;
    }

    public List<Instructor> getAll() {
        return repo.findAll();
    }
}
