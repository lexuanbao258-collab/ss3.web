package com.example.coursemanagement.service;

import com.example.coursemanagement.repository.*;
import org.springframework.stereotype.Service;

import java.util.*;

import com.example.coursemanagement.model.*;

@Service
public class EnrollmentService {
    private final EnrollmentRepository repo;

    public EnrollmentService(EnrollmentRepository repo) {
        this.repo = repo;
    }

    public List<Enrollment> getAll() {
        return repo.findAll();
    }
}
