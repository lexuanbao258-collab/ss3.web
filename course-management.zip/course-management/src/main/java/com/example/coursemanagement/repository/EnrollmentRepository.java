package com.example.coursemanagement.repository;

import com.example.coursemanagement.model.*;
import org.springframework.stereotype.Repository;

import java.util.*;

@Repository
public class EnrollmentRepository {
    public List<Enrollment> findAll() {
        return Arrays.asList(new Enrollment(1L, "Bao", 1L), new Enrollment(2L, "Nam", 2L));
    }
}
