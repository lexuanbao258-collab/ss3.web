package com.example.coursemanagement.service;

import com.example.coursemanagement.repository.*;
import org.springframework.stereotype.Service;

import java.util.*;

import com.example.coursemanagement.model.*;

@Service
public class CourseService {
    private final CourseRepository repo;

    public CourseService(CourseRepository repo) {
        this.repo = repo;
    }

    public List<Course> getAll() {
        return repo.findAll();
    }
}
