package com.example.coursemanagement.repository;

import com.example.coursemanagement.model.*;
import org.springframework.stereotype.Repository;

import java.util.*;

@Repository
public class CourseRepository {
    public List<Course> findAll() {
        return Arrays.asList(new Course(1L, "Java", "OPEN", 1L), new Course(2L, "Spring", "OPEN", 2L));
    }
}
