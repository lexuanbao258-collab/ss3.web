package com.example.coursemanagement.controller;

import org.springframework.stereotype.Controller;
import org.springframework.web.bind.annotation.*;
import com.example.coursemanagement.service.*;

@Controller
@ResponseBody
public class MainController {
    private final CourseService c;
    private final InstructorService i;
    private final EnrollmentService e;

    public MainController(CourseService c, InstructorService i, EnrollmentService e) {
        this.c = c;
        this.i = i;
        this.e = e;
    }

    @GetMapping("/courses")
    public Object courses() {
        return c.getAll();
    }

    @GetMapping("/instructors")
    public Object instructors() {
        return i.getAll();
    }

    @GetMapping("/enrollments")
    public Object enrollments() {
        return e.getAll();
    }
}
