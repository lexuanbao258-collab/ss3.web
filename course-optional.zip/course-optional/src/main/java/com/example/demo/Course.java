package com.example.demo;
import jakarta.persistence.*;
@Entity
public class Course {
  @Id @GeneratedValue
  private Long id;
  private String title;
  private String status;

  public Long getId() { return id; }
  public String getTitle() { return title; }
  public void setTitle(String title) { this.title = title; }
  public String getStatus() { return status; }
  public void setStatus(String status) { this.status = status; }
}