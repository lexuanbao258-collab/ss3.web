package com.example.demo;
import org.springframework.stereotype.Service;
@Service
public class CourseService {
  private final CourseRepository repo;
  public CourseService(CourseRepository repo) { this.repo = repo; }

  public Course findById(Long id) {
    return repo.findById(id)
      .orElseThrow(() -> new RuntimeException("Course not found"));
  }

  public Course update(Long id, Course c) {
    Course ex = findById(id);
    ex.setTitle(c.getTitle());
    ex.setStatus(c.getStatus());
    return repo.save(ex);
  }

  public void delete(Long id) {
    Course ex = findById(id);
    repo.delete(ex);
  }
}
