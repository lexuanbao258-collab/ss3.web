package com.example.demo;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.*;

@RestController
@RequestMapping("/courses")
public class CourseController {
  private final CourseService service;
  public CourseController(CourseService service) { this.service = service; }

  @GetMapping("/{id}")
  public ResponseEntity<?> get(@PathVariable Long id) {
    try {
      return ResponseEntity.ok(service.findById(id));
    } catch (RuntimeException e) {
      return ResponseEntity.status(404).body(e.getMessage());
    }
  }

  @PutMapping("/{id}")
  public ResponseEntity<?> update(@PathVariable Long id, @RequestBody Course c) {
    try {
      return ResponseEntity.ok(service.update(id, c));
    } catch (RuntimeException e) {
      return ResponseEntity.status(404).body(e.getMessage());
    }
  }

  @DeleteMapping("/{id}")
  public ResponseEntity<?> delete(@PathVariable Long id) {
    try {
      service.delete(id);
      return ResponseEntity.ok("Deleted");
    } catch (RuntimeException e) {
      return ResponseEntity.status(404).body(e.getMessage());
    }
  }
}
