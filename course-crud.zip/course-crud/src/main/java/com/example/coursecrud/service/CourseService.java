package com.example.coursecrud.service;

import com.example.coursecrud.repository.*;
import com.example.coursecrud.model.*;
import org.springframework.stereotype.Service;

import java.util.*;

@Service
public class CourseService {
    private final CourseRepository repo;

    public CourseService(CourseRepository repo) {
        this.repo = repo;
    }

    public List<Course> getAll() {
        return repo.findAll();
    }

    public Course getById(Long id) {
        return repo.findById(id);
    }

    public Course create(Course o) {
        return repo.create(o);
    }

    public Course update(Long id, Course o) {
        return repo.update(id, o);
    }

    public Course delete(Long id) {
        return repo.deleteById(id);
    }
}
