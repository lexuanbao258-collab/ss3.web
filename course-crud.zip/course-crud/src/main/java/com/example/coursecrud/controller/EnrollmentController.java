package com.example.coursecrud.controller;

import org.springframework.web.bind.annotation.*;
import org.springframework.http.*;
import com.example.coursecrud.service.*;
import com.example.coursecrud.model.*;

@RestController
@RequestMapping("/enrollments")
public class EnrollmentController {
    private final EnrollmentService s;

    public EnrollmentController(EnrollmentService s) {
        this.s = s;
    }

    @GetMapping
    public ResponseEntity<?> all() {
        return ResponseEntity.ok(s.getAll());
    }

    @GetMapping("/{id}")
    public ResponseEntity<?> one(@PathVariable Long id) {
        Enrollment o = s.getById(id);
        return o == null ? ResponseEntity.status(404).body("Not found") : ResponseEntity.ok(o);
    }

    @PostMapping
    public ResponseEntity<?> create(@RequestBody Enrollment o) {
        return ResponseEntity.status(201).body(s.create(o));
    }

    @PutMapping("/{id}")
    public ResponseEntity<?> update(@PathVariable Long id, @RequestBody Enrollment o) {
        Enrollment r = s.update(id, o);
        return r == null ? ResponseEntity.status(404).body("Not found") : ResponseEntity.ok(r);
    }

    @DeleteMapping("/{id}")
    public ResponseEntity<?> delete(@PathVariable Long id) {
        Enrollment r = s.delete(id);
        return r == null ? ResponseEntity.status(404).body("Not found") : ResponseEntity.ok(r);
    }
}
