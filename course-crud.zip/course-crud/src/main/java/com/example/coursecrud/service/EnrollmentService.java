package com.example.coursecrud.service;

import com.example.coursecrud.repository.*;
import com.example.coursecrud.model.*;
import org.springframework.stereotype.Service;

import java.util.*;

@Service
public class EnrollmentService {
    private final EnrollmentRepository repo;

    public EnrollmentService(EnrollmentRepository repo) {
        this.repo = repo;
    }

    public List<Enrollment> getAll() {
        return repo.findAll();
    }

    public Enrollment getById(Long id) {
        return repo.findById(id);
    }

    public Enrollment create(Enrollment o) {
        return repo.create(o);
    }

    public Enrollment update(Long id, Enrollment o) {
        return repo.update(id, o);
    }

    public Enrollment delete(Long id) {
        return repo.deleteById(id);
    }
}
