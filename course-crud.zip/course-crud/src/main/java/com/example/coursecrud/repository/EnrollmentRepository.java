package com.example.coursecrud.repository;

import com.example.coursecrud.model.*;
import org.springframework.stereotype.Repository;

import java.util.*;

@Repository
public class EnrollmentRepository {
    private List<Enrollment> list = new ArrayList<>();

    public List<Enrollment> findAll() {
        return list;
    }

    public Enrollment findById(Long id) {
        return list.stream().filter(x -> x.id.equals(id)).findFirst().orElse(null);
    }

    public Enrollment create(Enrollment o) {
        list.add(o);
        return o;
    }

    public Enrollment update(Long id, Enrollment o) {
        deleteById(id);
        list.add(o);
        return o;
    }

    public Enrollment deleteById(Long id) {
        Enrollment obj = findById(id);
        if (obj != null) list.remove(obj);
        return obj;
    }
}
