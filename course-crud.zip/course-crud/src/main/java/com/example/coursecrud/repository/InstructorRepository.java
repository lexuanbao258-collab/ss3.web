package com.example.coursecrud.repository;

import com.example.coursecrud.model.*;
import org.springframework.stereotype.Repository;

import java.util.*;

@Repository
public class InstructorRepository {
    private List<Instructor> list = new ArrayList<>();

    public List<Instructor> findAll() {
        return list;
    }

    public Instructor findById(Long id) {
        return list.stream().filter(x -> x.id.equals(id)).findFirst().orElse(null);
    }

    public Instructor create(Instructor o) {
        list.add(o);
        return o;
    }

    public Instructor update(Long id, Instructor o) {
        deleteById(id);
        list.add(o);
        return o;
    }

    public Instructor deleteById(Long id) {
        Instructor obj = findById(id);
        if (obj != null) list.remove(obj);
        return obj;
    }
}
