package com.example.coursecrud.model;

public class Course {
    public Long id;
    public String title;
    public String status;
    public Long instructorId;
}
