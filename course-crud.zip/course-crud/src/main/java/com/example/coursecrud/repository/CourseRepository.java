package com.example.coursecrud.repository;

import com.example.coursecrud.model.*;
import org.springframework.stereotype.Repository;

import java.util.*;

@Repository
public class CourseRepository {
    private List<Course> list = new ArrayList<>();

    public List<Course> findAll() {
        return list;
    }

    public Course findById(Long id) {
        return list.stream().filter(x -> x.id.equals(id)).findFirst().orElse(null);
    }

    public Course create(Course o) {
        list.add(o);
        return o;
    }

    public Course update(Long id, Course o) {
        deleteById(id);
        list.add(o);
        return o;
    }

    public Course deleteById(Long id) {
        Course obj = findById(id);
        if (obj != null) list.remove(obj);
        return obj;
    }
}
