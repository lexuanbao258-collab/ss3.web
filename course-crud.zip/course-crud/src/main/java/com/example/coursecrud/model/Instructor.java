package com.example.coursecrud.model;

public class Instructor {
    public Long id;
    public String name;
    public String email;
}
