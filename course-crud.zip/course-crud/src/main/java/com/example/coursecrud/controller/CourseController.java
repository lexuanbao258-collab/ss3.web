package com.example.coursecrud.controller;

import org.springframework.web.bind.annotation.*;
import org.springframework.http.*;
import com.example.coursecrud.service.*;
import com.example.coursecrud.model.*;

@RestController
@RequestMapping("/courses")
public class CourseController {
    private final CourseService s;

    public CourseController(CourseService s) {
        this.s = s;
    }

    @GetMapping
    public ResponseEntity<?> all() {
        return ResponseEntity.ok(s.getAll());
    }

    @GetMapping("/{id}")
    public ResponseEntity<?> one(@PathVariable Long id) {
        Course o = s.getById(id);
        return o == null ? ResponseEntity.status(404).body("Not found") : ResponseEntity.ok(o);
    }

    @PostMapping
    public ResponseEntity<?> create(@RequestBody Course o) {
        return ResponseEntity.status(201).body(s.create(o));
    }

    @PutMapping("/{id}")
    public ResponseEntity<?> update(@PathVariable Long id, @RequestBody Course o) {
        Course r = s.update(id, o);
        return r == null ? ResponseEntity.status(404).body("Not found") : ResponseEntity.ok(r);
    }

    @DeleteMapping("/{id}")
    public ResponseEntity<?> delete(@PathVariable Long id) {
        Course r = s.delete(id);
        return r == null ? ResponseEntity.status(404).body("Not found") : ResponseEntity.ok(r);
    }
}
