package com.example.coursecrud.service;

import com.example.coursecrud.repository.*;
import com.example.coursecrud.model.*;
import org.springframework.stereotype.Service;

import java.util.*;

@Service
public class InstructorService {
    private final InstructorRepository repo;

    public InstructorService(InstructorRepository repo) {
        this.repo = repo;
    }

    public List<Instructor> getAll() {
        return repo.findAll();
    }

    public Instructor getById(Long id) {
        return repo.findById(id);
    }

    public Instructor create(Instructor o) {
        return repo.create(o);
    }

    public Instructor update(Long id, Instructor o) {
        return repo.update(id, o);
    }

    public Instructor delete(Long id) {
        return repo.deleteById(id);
    }
}
