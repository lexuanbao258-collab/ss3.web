package com.example.coursecrud.model;

public class Enrollment {
    public Long id;
    public String studentName;
    public Long courseId;
}
